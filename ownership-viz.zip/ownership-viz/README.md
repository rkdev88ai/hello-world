# Ownership Structure Explorer

An interactive corporate ownership / UBO (Ultimate Beneficial Owner) visualisation built with
React and Cytoscape.js. Shows the client entity at the base of the chart and unwraps its
ownership chain upward — companies, trusts, aggregated fund pools, nominees and individuals —
loading three levels by default and fetching further levels on demand as you click through.

## How it works

- **Entity picker**: the dropdown in the header lists all sample companies, grouped into
  "Real-world" (grounded in public reporting) and "Illustrative" (fictional but realistic bank
  scenarios). Choosing one loads that company's ownership graph from scratch.
- **Data**: each file in `src/data/samples/` is a flat entity map plus an ownership-edge list
  (`ownerId`, `ownedId`, `percentage`, ...), with a `meta` block (`label`, `category`, `tags`,
  `sourceNote`) that drives the dropdown and the note banner under the header.
  `src/data/samples/index.js` lists them — add a new JSON file and one import line to add a
  sample. Point `src/services/ownershipService.js` at a real API instead to use live data;
  nothing else in the app needs to change.
- **Lazy loading**: `ownershipService.fetchOwners(entityId)` simulates an async per-node API
  call. On first load the app auto-expands 3 levels above the client entity. Clicking any node
  that still has undisclosed owners loads the next level; nodes with no further data are marked
  as the end of the chain — this keeps working however deep the real chain goes.
- **Cyclical ownership**: several samples (Tata Motors, Samsung Electronics, and the dedicated
  "Lighthouse" demo) include real or illustrative circular cross-shareholdings, where an entity
  several levels up ends up owning a slice of an entity already on the canvas. The graph detects
  the node already exists and simply draws the extra edge — no duplicate nodes, no infinite
  loops.
- **Visual language**: rectangles = corporates, hexagons = trusts, dashed rectangles = pooled/
  nominee holdings (red dashing = a disclosure gap to escalate), circles = individuals — the gold
  ring fills according to that person's effective (cumulative, multiplied-through) stake in the
  client entity. Clicking a node also highlights its ownership path down to the client entity.

## Sample companies included

| # | Client entity | Category | Notable pattern |
|---|---|---|---|
| 1 | Meridian Trade Finance Ltd | Illustrative | PE fund GP/LP dilution, trust, undisclosed nominee |
| 2 | Alphabet Inc. | Real-world | Dual-class share control (intentionally shallow) |
| 3 | Tata Motors Limited | Real-world | Cyclical cross-holding back into Tata Sons |
| 4 | Samsung Electronics Co., Ltd. | Real-world | Converging cross-shareholding (Samsung C&T) |
| 5 | Volkswagen AG | Real-world | Family holding + state + sovereign wealth fund |
| 6 | LVMH Moët Hennessy Louis Vuitton SE | Real-world | 5-level family holding chain, equal sibling split |
| 7 | Reliance Industries Limited | Real-world | Family trust succession structure |
| 8 | Atlas Precision Components Ltd | Illustrative | Full PE leveraged-buyout chain (BidCo/MidCo/TopCo), 6 levels |
| 9 | Coral Strait Bulk Carriers Pte Ltd | Illustrative | Shipping JV with partial ownership at every level |
| 10 | Lighthouse Industrial Holdings Ltd | Illustrative | Clean, deliberately simple ownership cycle |

The "Real-world" samples use approximate, illustrative figures drawn from public reporting (SEC
filings, press coverage) — each has a `sourceNote` shown in the app and is **not** an exact or
current shareholding register. Don't use them for actual compliance decisions.

## Prerequisites (Windows)

1. **Node.js LTS** (v18 or newer — v20/22 both work). Download from
   https://nodejs.org and run the installer with default options. This also installs `npm`.
2. Confirm the install by opening **PowerShell** or **Command Prompt** and running:
   ```
   node -v
   npm -v
   ```
   Both should print a version number.

## Running it locally

1. Copy the `ownership-viz` folder anywhere on your laptop, e.g. `C:\Users\<you>\Projects\ownership-viz`.
2. Open PowerShell in that folder (Shift + right-click the folder → "Open PowerShell window here",
   or `cd` into it manually).
3. Install dependencies (one-time, needs internet access):
   ```
   npm install
   ```
4. Start the development server:
   ```
   npm run dev
   ```
5. Vite will print a local URL (typically `http://localhost:5173`) and should open it in your
   default browser automatically. If not, open it manually.
6. To stop the server, go back to the terminal and press `Ctrl + C`.

## Building a static, shareable version

If you want a version that doesn't need `npm run dev` running (e.g. to email as a folder or host
on an internal file share / intranet server):

```
npm run build
```

This produces a `dist/` folder containing plain HTML/CSS/JS. You can:
- Double-click `dist/index.html` directly in most browsers (Cytoscape and the graph will still
  render; if your browser blocks local module loading, use the preview server instead), or
- Run `npm run preview` to serve the built version at `http://localhost:4173`, or
- Copy the `dist/` folder to any static web server / intranet host.

## Adding your own sample or swapping in real data

- **Add another sample company**: drop a new JSON file (same shape as the ones in
  `src/data/samples/`) into that folder, then import it and add it to the `RAW_SAMPLES` array in
  `src/data/samples/index.js`. It appears in the dropdown automatically.
- **Connect a real backend**: replace the two functions inside `createOwnershipService()` in
  `src/services/ownershipService.js` (`fetchOwners` and `hasOwners`) with calls to your actual
  UBO/registry/KYC data API. The rest of the application (graph rendering, lazy expansion, detail
  panel, dropdown) requires no changes.

## Project structure

```
ownership-viz/
├── index.html
├── package.json
├── vite.config.js
├── README.md
└── src/
    ├── main.jsx                  # React entry point
    ├── App.jsx                   # Layout: header, graph, legend, detail panel
    ├── styles.css                # Design tokens and layout
    ├── cytoscapeConfig.js        # Cytoscape stylesheet + dagre layout config
    ├── components/
    │   ├── OwnershipGraph.jsx    # Cytoscape instance, lazy-expand logic
    │   ├── DetailPanel.jsx       # Right-hand entity detail panel
    │   ├── Legend.jsx            # Visual-language key
    │   ├── Header.jsx            # Top bar: title, sample dropdown, reset
    │   └── SampleSelector.jsx    # The entity-picker dropdown
    ├── data/
    │   └── samples/              # 10 ownership datasets + index.js
    └── services/
        └── ownershipService.js   # Data-access layer, factory per dataset
```
