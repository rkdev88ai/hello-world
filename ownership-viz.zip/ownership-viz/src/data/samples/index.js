import s01 from './01-meridian-trade-finance.json';
import s02 from './02-alphabet-inc.json';
import s03 from './03-tata-motors.json';
import s04 from './04-samsung-electronics.json';
import s05 from './05-volkswagen-porsche.json';
import s06 from './06-lvmh-arnault.json';
import s07 from './07-reliance-industries.json';
import s08 from './08-atlas-precision-lbo.json';
import s09 from './09-coral-strait-shipping.json';
import s10 from './10-lighthouse-cross-holding.json';

// Each dataset carries its own `meta` block (label, category, tags, sourceNote)
// plus the `rootId` / `entities` / `ownership` shape the ownership service
// expects. Add a new sample by dropping a JSON file next to these and
// importing it here — nothing else needs to change.
const RAW_SAMPLES = [s01, s02, s03, s04, s05, s06, s07, s08, s09, s10];

export const SAMPLES = RAW_SAMPLES.map((dataset, index) => ({
  id: dataset.rootId || `sample-${index}`,
  label: dataset.meta?.label ?? dataset.rootId,
  category: dataset.meta?.category ?? 'Illustrative',
  tags: dataset.meta?.tags ?? [],
  sourceNote: dataset.meta?.sourceNote ?? '',
  dataset
}));

export const DEFAULT_SAMPLE_ID = SAMPLES[0].id;
