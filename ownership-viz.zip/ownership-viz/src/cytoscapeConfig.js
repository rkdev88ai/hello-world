// Central place for cytoscape visual language. Colors are read from CSS
// custom properties at runtime so the graph always matches the app theme
// defined in styles.css — change the palette in one place only.

function cssVar(name, fallback) {
  const v = getComputedStyle(document.documentElement).getPropertyValue(name);
  return (v && v.trim()) || fallback;
}

export function buildStylesheet() {
  const navy = cssVar('--navy', '#0b1e33');
  const slate = cssVar('--slate', '#1e3a56');
  const steel = cssVar('--steel', '#4a6c8c');
  const gold = cssVar('--gold', '#c9974d');
  const paper = cssVar('--paper', '#f6f7f9');
  const ink = cssVar('--ink', '#1a1f26');
  const line = cssVar('--line', '#c7cfd8');
  const danger = cssVar('--danger', '#b5482f');
  const ring = cssVar('--ring-track', '#e3e7ec');

  return [
    {
      selector: 'core',
      style: { 'active-bg-opacity': 0 }
    },
    // ---- Edges ----------------------------------------------------------
    {
      selector: 'edge',
      style: {
        width: 1.6,
        'line-color': line,
        'target-arrow-color': line,
        'target-arrow-shape': 'triangle',
        'arrow-scale': 0.9,
        'curve-style': 'bezier',
        label: 'data(pctLabel)',
        'font-family': 'IBM Plex Mono, monospace',
        'font-size': 10,
        color: steel,
        'text-background-color': paper,
        'text-background-opacity': 1,
        'text-background-padding': 2,
        'text-rotation': 'autorotate'
      }
    },
    {
      selector: 'edge.flagged',
      style: { 'line-color': danger, 'target-arrow-color': danger, 'line-style': 'dashed' }
    },
    // ---- Base node --------------------------------------------------------
    {
      selector: 'node',
      style: {
        'font-family': 'IBM Plex Sans, sans-serif',
        'font-size': 12,
        'font-weight': 500,
        color: ink,
        'text-wrap': 'wrap',
        'text-max-width': '150px',
        'text-valign': 'bottom',
        'text-margin-y': 8,
        'overlay-opacity': 0
      }
    },
    // ---- Root / company (rectangle "certificate" card) -------------------
    {
      selector: 'node[type="company"]',
      style: {
        shape: 'round-rectangle',
        width: 150,
        height: 56,
        'background-color': '#ffffff',
        'border-width': 2,
        'border-color': slate,
        label: 'data(name)',
        'text-valign': 'center',
        'text-halign': 'center',
        'text-max-width': '130px',
        'font-weight': 600
      }
    },
    {
      selector: 'node[isRoot]',
      style: {
        'border-width': 3,
        'border-color': navy,
        'background-color': navy,
        color: '#ffffff',
        width: 180,
        height: 64,
        'font-size': 13
      }
    },
    // ---- Trust (hexagon) ---------------------------------------------------
    {
      selector: 'node[type="trust"]',
      style: {
        shape: 'hexagon',
        width: 130,
        height: 70,
        'background-color': '#eef2f6',
        'border-width': 2,
        'border-color': steel,
        label: 'data(name)',
        'text-valign': 'center',
        'text-halign': 'center',
        'text-max-width': '100px'
      }
    },
    // ---- Aggregate pool (dashed rectangle) ---------------------------------
    {
      selector: 'node[type="aggregate"]',
      style: {
        shape: 'round-rectangle',
        width: 170,
        height: 56,
        'background-color': '#f1f1ec',
        'border-width': 2,
        'border-style': 'dashed',
        'border-color': steel,
        label: 'data(name)',
        'text-valign': 'center',
        'text-halign': 'center',
        'text-max-width': '150px',
        'font-style': 'italic'
      }
    },
    // ---- Nominee / opaque (flagged) ---------------------------------------
    {
      selector: 'node[type="nominee"]',
      style: {
        shape: 'round-rectangle',
        width: 170,
        height: 56,
        'background-color': '#fbeee9',
        'border-width': 2,
        'border-style': 'dashed',
        'border-color': danger,
        label: 'data(name)',
        'text-valign': 'center',
        'text-halign': 'center',
        'text-max-width': '150px',
        color: danger,
        'font-style': 'italic'
      }
    },
    // ---- Individual (circle with ownership ring) ---------------------------
    {
      selector: 'node[type="individual"]',
      style: {
        shape: 'ellipse',
        width: 64,
        height: 64,
        'background-color': '#ffffff',
        'border-width': 3,
        'border-color': ring,
        label: 'data(name)',
        'text-valign': 'bottom',
        'text-margin-y': 6,
        'pie-size': '92%',
        'pie-1-background-color': gold,
        'pie-1-background-size': 'data(effectivePct)',
        'pie-2-background-color': ring,
        'pie-2-background-size': 'data(effectiveRemainder)'
      }
    },
    {
      selector: 'node[type="individual"][?isUBO]',
      style: { 'border-color': gold, 'border-width': 3 }
    },
    // ---- Interaction states -------------------------------------------------
    {
      selector: 'node.expandable',
      style: { 'border-style': 'solid' }
    },
    {
      selector: 'node.loading',
      style: { 'background-color': '#eef2f6', opacity: 0.7 }
    },
    {
      selector: 'node:selected',
      style: {
        'border-width': 4,
        'border-color': gold,
        'box-shadow-blur': 12
      }
    },
    {
      selector: '.dim',
      style: { opacity: 0.25 }
    },
    {
      selector: '.highlight-path',
      style: { 'line-color': gold, 'target-arrow-color': gold, width: 2.4, opacity: 1 }
    }
  ];
}

export const layoutConfig = {
  name: 'dagre',
  rankDir: 'TB', // edges run owner -> owned, so dagre naturally places ultimate owners
  // at the top rank and lets ownership flow down onto the client entity at the base
  nodeSep: 55,
  rankSep: 110,
  edgeSep: 20,
  animate: true,
  animationDuration: 450,
  animationEasing: 'ease-in-out-cubic',
  fit: true,
  padding: 60
};
