import { useCallback, useRef, useState } from 'react';
import Header from './components/Header';
import Legend from './components/Legend';
import DetailPanel from './components/DetailPanel';
import OwnershipGraph from './components/OwnershipGraph';
import { SAMPLES, DEFAULT_SAMPLE_ID } from './data/samples';

export default function App() {
  const [selectedId, setSelectedId] = useState(DEFAULT_SAMPLE_ID);
  const [selection, setSelection] = useState(null);
  const [statusMessage, setStatusMessage] = useState('');
  const apiRef = useRef(null);

  const sample = SAMPLES.find((s) => s.id === selectedId) ?? SAMPLES[0];

  const handleSelectSample = useCallback((id) => {
    setSelectedId(id);
    setSelection(null);
    setStatusMessage('');
  }, []);

  const handleReset = useCallback(() => {
    setSelection(null);
    apiRef.current?.resetView();
  }, []);

  return (
    <div className="app-shell">
      <Header
        selectedId={selectedId}
        onSelectSample={handleSelectSample}
        onReset={handleReset}
        statusMessage={statusMessage}
      />
      {sample.sourceNote && (
        <div className="sample-note">
          <span className="sample-note-tag">{sample.category}</span>
          {sample.sourceNote}
        </div>
      )}
      <div className="app-body">
        <div className="graph-pane">
          <OwnershipGraph
            key={selectedId}
            dataset={sample.dataset}
            onSelectEntity={setSelection}
            onStatusMessage={setStatusMessage}
            registerApi={(api) => {
              apiRef.current = api;
            }}
          />
          <Legend />
        </div>
        <DetailPanel selection={selection} />
      </div>
    </div>
  );
}
