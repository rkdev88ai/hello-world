// ---------------------------------------------------------------------------
// This module simulates a backend UBO/ownership-lookup service, scoped to a
// single dataset (one sample company's ownership graph). In production,
// replace the two per-instance functions below with real calls, e.g.
// `fetch(`/api/ownership/${entityId}/owners`)`. Everything upstream (the
// graph component) only depends on this contract, so swapping the
// implementation requires no changes elsewhere.
// ---------------------------------------------------------------------------

const NETWORK_DELAY_MS = 450;

function delay(value) {
  return new Promise((resolve) => setTimeout(() => resolve(value), NETWORK_DELAY_MS));
}

/**
 * Builds an ownership service bound to one dataset. Call this once per
 * selected sample (e.g. via useMemo keyed on the sample id) so switching
 * companies in the UI never mixes data between graphs.
 */
export function createOwnershipService(dataset) {
  return {
    getRootEntityId() {
      return dataset.rootId;
    },

    getEntitySync(entityId) {
      return dataset.entities[entityId] || null;
    },

    /**
     * Returns the direct owners of a given entity: the ownership edge plus
     * the owning entity's attributes. Simulates an async, per-node API call
     * so the UI can lazy-load one level at a time instead of shipping the
     * whole graph up front.
     */
    async fetchOwners(entityId) {
      const edges = dataset.ownership.filter((e) => e.ownedId === entityId);
      const owners = edges.map((edge) => ({
        edge,
        entity: dataset.entities[edge.ownerId]
      }));
      return delay(owners);
    },

    /**
     * Synchronous existence check (no network) so the UI can decide whether
     * to render an "expand" affordance on a node without waiting on a round
     * trip.
     */
    hasOwners(entityId) {
      const entity = dataset.entities[entityId];
      if (entity && entity.isTerminal) return false;
      return dataset.ownership.some((e) => e.ownedId === entityId);
    }
  };
}
