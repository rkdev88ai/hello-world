const TYPE_LABELS = {
  company: 'Corporate entity',
  individual: 'Individual',
  trust: 'Trust',
  aggregate: 'Aggregated holding pool',
  nominee: 'Nominee / custodian account'
};

export default function DetailPanel({ selection }) {
  if (!selection) {
    return (
      <aside className="detail-panel detail-panel--empty">
        <p className="detail-empty-hint">
          Click any entity in the structure to view its detail and load the next level of ownership
          above it.
        </p>
      </aside>
    );
  }

  const { entity, terminal, pending } = selection;

  return (
    <aside className="detail-panel">
      <div className="detail-kicker">{TYPE_LABELS[entity.type] || entity.type}</div>
      <h2 className="detail-name">{entity.name}</h2>

      {entity.riskFlag && (
        <div className="detail-flag">Underlying ownership not disclosed — flag for escalation</div>
      )}
      {entity.isUBO && <div className="detail-ubo">Identified Ultimate Beneficial Owner</div>}

      <dl className="detail-fields">
        {entity.jurisdiction && (
          <>
            <dt>Jurisdiction</dt>
            <dd>{entity.jurisdiction}</dd>
          </>
        )}
        {entity.regNumber && (
          <>
            <dt>Registration no.</dt>
            <dd>{entity.regNumber}</dd>
          </>
        )}
        {entity.role && (
          <>
            <dt>Role</dt>
            <dd>{entity.role}</dd>
          </>
        )}
        <dt>Effective stake in client entity</dt>
        <dd className="detail-pct">{entity.effectivePct}%</dd>
        {entity.note && (
          <>
            <dt>Note</dt>
            <dd>{entity.note}</dd>
          </>
        )}
      </dl>

      <div className="detail-status">
        {pending && <span className="status-pending">Loading ownership above this entity…</span>}
        {!pending && terminal && <span className="status-terminal">End of disclosed chain — no further owners on record.</span>}
        {!pending && !terminal && <span className="status-loaded">Ownership above this entity is now shown on the canvas.</span>}
      </div>
    </aside>
  );
}
