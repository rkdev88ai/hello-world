import { useEffect, useMemo, useRef, useCallback } from 'react';
import cytoscape from 'cytoscape';
import dagre from 'cytoscape-dagre';
import { createOwnershipService } from '../services/ownershipService';
import { buildStylesheet, layoutConfig } from '../cytoscapeConfig';

cytoscape.use(dagre);

const DEFAULT_AUTO_LEVELS = 3;

function nodeExists(cy, id) {
  return cy.getElementById(id).length > 0;
}
function edgeExists(cy, id) {
  return cy.getElementById(id).length > 0;
}

export default function OwnershipGraph({ dataset, onSelectEntity, onStatusMessage, registerApi }) {
  const containerRef = useRef(null);
  const cyRef = useRef(null);
  const expandedRef = useRef(new Set());

  // Bind the data-access layer to this dataset. The component is remounted
  // (via a `key` prop from the parent) whenever the selected sample changes,
  // so this only ever runs once per mount.
  const service = useMemo(() => createOwnershipService(dataset), [dataset]);

  const addOwnerNode = useCallback((cy, entity, level, cumulative) => {
    if (nodeExists(cy, entity.id)) return;
    cy.add({
      group: 'nodes',
      data: {
        id: entity.id,
        name: entity.name,
        type: entity.type,
        jurisdiction: entity.jurisdiction,
        regNumber: entity.regNumber || '',
        role: entity.role || '',
        note: entity.note || '',
        isUBO: !!entity.isUBO,
        riskFlag: !!entity.riskFlag,
        level,
        cumulative,
        effectivePct: Math.round(cumulative * 1000) / 10,
        effectiveRemainder: 100 - Math.round(cumulative * 1000) / 10,
        isRoot: entity.id === service.getRootEntityId() ? true : undefined
      }
    });
  }, [service]);

  const addOwnershipEdge = useCallback((cy, edge, flagged) => {
    if (edgeExists(cy, edge.id)) return;
    cy.add({
      group: 'edges',
      data: {
        id: edge.id,
        source: edge.ownerId,
        target: edge.ownedId,
        percentage: edge.percentage,
        pctLabel: `${edge.percentage}%`,
        shareClass: edge.shareClass
      },
      classes: flagged ? 'flagged' : ''
    });
  }, []);

  const expandNode = useCallback(
    async (entityId, { silent } = {}) => {
      const cy = cyRef.current;
      if (!cy) return;
      const node = cy.getElementById(entityId);
      if (node.empty()) return;

      if (expandedRef.current.has(entityId)) return;

      if (!service.hasOwners(entityId)) {
        expandedRef.current.add(entityId);
        node.addClass('terminal-checked');
        if (!silent) {
          onStatusMessage?.(`"${node.data('name')}" has no further disclosed ownership — chain fully resolved.`);
        }
        return;
      }

      node.addClass('loading');
      const owners = await service.fetchOwners(entityId);
      node.removeClass('loading');

      const parentLevel = node.data('level') ?? 0;
      const parentCumulative = node.data('cumulative') ?? 1;

      owners.forEach(({ edge, entity }) => {
        const cumulative = parentCumulative * (edge.percentage / 100);
        addOwnerNode(cy, entity, parentLevel + 1, cumulative);
        addOwnershipEdge(cy, edge, !!entity.riskFlag);
        if (service.hasOwners(entity.id)) {
          cy.getElementById(entity.id).addClass('expandable');
        }
      });

      expandedRef.current.add(entityId);
      node.removeClass('expandable');

      cy.layout(layoutConfig).run();

      if (!silent) {
        onStatusMessage?.(`Loaded ${owners.length} owner${owners.length === 1 ? '' : 's'} of "${node.data('name')}".`);
      }
    },
    [service, addOwnerNode, addOwnershipEdge, onStatusMessage]
  );

  const highlightPathToRoot = useCallback(
    (cy, nodeId) => {
      cy.edges().removeClass('highlight-path');
      cy.elements().removeClass('dim');
      const rootId = service.getRootEntityId();
      let currentId = nodeId;
      let guard = 0;
      while (currentId !== rootId && guard < 50) {
        const outgoing = cy.edges(`[source = "${currentId}"]`);
        if (outgoing.empty()) break;
        outgoing.addClass('highlight-path');
        currentId = outgoing.data('target');
        guard += 1;
      }
    },
    [service]
  );

  const initGraph = useCallback(
    async (cy) => {
      const rootId = service.getRootEntityId();
      const rootEntity = service.getEntitySync(rootId);
      addOwnerNode(cy, rootEntity, 0, 1);

      // Auto-load the first N levels so the user sees a meaningful default
      // structure without having to click anything first.
      let frontier = [rootId];
      for (let level = 0; level < DEFAULT_AUTO_LEVELS; level += 1) {
        const next = [];
        // eslint-disable-next-line no-await-in-loop
        await Promise.all(
          frontier.map(async (id) => {
            if (!service.hasOwners(id)) return;
            const owners = await service.fetchOwners(id);
            const parentNode = cy.getElementById(id);
            const parentCumulative = parentNode.data('cumulative') ?? 1;
            const parentLevel = parentNode.data('level') ?? 0;
            owners.forEach(({ edge, entity }) => {
              const cumulative = parentCumulative * (edge.percentage / 100);
              addOwnerNode(cy, entity, parentLevel + 1, cumulative);
              addOwnershipEdge(cy, edge, !!entity.riskFlag);
              next.push(entity.id);
            });
            expandedRef.current.add(id);
          })
        );
        frontier = next;
      }
      // Mark remaining frontier nodes as expandable (they have data but are
      // deliberately not auto-loaded past the default depth).
      frontier.forEach((id) => {
        if (service.hasOwners(id)) cy.getElementById(id).addClass('expandable');
      });

      cy.layout(layoutConfig).run();
      onStatusMessage?.(
        `Showing ${DEFAULT_AUTO_LEVELS} levels of ownership above ${rootEntity.name}. Click any highlighted entity to trace further.`
      );
    },
    [service, addOwnerNode, addOwnershipEdge, onStatusMessage]
  );

  const focusOnEntity = useCallback(
    (entityId) => {
      const cy = cyRef.current;
      if (!cy) return;
      const node = cy.getElementById(entityId);
      if (node.empty()) return;
      highlightPathToRoot(cy, entityId);
      cy.animate({ center: { eles: node }, zoom: Math.max(cy.zoom(), 1) }, { duration: 350 });
    },
    [highlightPathToRoot]
  );

  const resetView = useCallback(() => {
    const cy = cyRef.current;
    if (!cy) return;
    cy.elements().remove();
    expandedRef.current = new Set();
    initGraph(cy);
  }, [initGraph]);

  useEffect(() => {
    const cy = cytoscape({
      container: containerRef.current,
      style: buildStylesheet(),
      wheelSensitivity: 0.25,
      minZoom: 0.25,
      maxZoom: 2.5
    });
    cyRef.current = cy;

    cy.on('tap', 'node', async (evt) => {
      const node = evt.target;
      const entityId = node.id();
      highlightPathToRoot(cy, entityId);

      const alreadyExpanded = expandedRef.current.has(entityId);
      onSelectEntity?.({
        entity: node.data(),
        terminal: alreadyExpanded && !service.hasOwners(entityId),
        pending: !alreadyExpanded
      });

      if (!alreadyExpanded) {
        await expandNode(entityId, { silent: false });
        const refreshed = cy.getElementById(entityId);
        onSelectEntity?.({
          entity: refreshed.data(),
          terminal: !service.hasOwners(entityId),
          pending: false
        });
      }
    });

    cy.on('tap', (evt) => {
      if (evt.target === cy) {
        cy.edges().removeClass('highlight-path');
        cy.elements().removeClass('dim');
      }
    });

    initGraph(cy);
    registerApi?.({ focusOnEntity, resetView });

    return () => {
      cy.destroy();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div ref={containerRef} className="graph-canvas" role="img" aria-label="Corporate ownership structure graph" />
  );
}
