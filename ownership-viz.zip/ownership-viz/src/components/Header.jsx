import SampleSelector from './SampleSelector';

export default function Header({ selectedId, onSelectSample, onReset, statusMessage }) {
  return (
    <header className="app-header">
      <div className="app-header-title">
        <span className="app-header-eyebrow">CIB · Client Onboarding</span>
        <h1>Ownership Structure Explorer</h1>
      </div>

      <SampleSelector selectedId={selectedId} onChange={onSelectSample} />

      <div className="app-header-status" aria-live="polite">
        {statusMessage}
      </div>

      <button type="button" className="btn-reset" onClick={onReset}>
        Reset view
      </button>
    </header>
  );
}
