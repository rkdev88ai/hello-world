export default function Legend() {
  return (
    <div className="legend">
      <div className="legend-title">Legend</div>
      <div className="legend-row">
        <span className="swatch swatch-root" /> Client entity (root)
      </div>
      <div className="legend-row">
        <span className="swatch swatch-company" /> Corporate owner
      </div>
      <div className="legend-row">
        <span className="swatch swatch-trust" /> Trust
      </div>
      <div className="legend-row">
        <span className="swatch swatch-individual" /> Individual — ring shows effective stake
      </div>
      <div className="legend-row">
        <span className="swatch swatch-ubo" /> Confirmed UBO
      </div>
      <div className="legend-row">
        <span className="swatch swatch-flag" /> Disclosure gap / escalate
      </div>
    </div>
  );
}
