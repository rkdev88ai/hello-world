import { SAMPLES } from '../data/samples';

export default function SampleSelector({ selectedId, onChange }) {
  const grouped = SAMPLES.reduce((acc, sample) => {
    (acc[sample.category] ||= []).push(sample);
    return acc;
  }, {});

  return (
    <div className="sample-selector">
      <label htmlFor="sample-select" className="sample-selector-label">
        Client entity
      </label>
      <select
        id="sample-select"
        className="sample-selector-input"
        value={selectedId}
        onChange={(e) => onChange(e.target.value)}
      >
        {Object.entries(grouped).map(([category, samples]) => (
          <optgroup key={category} label={category}>
            {samples.map((sample) => (
              <option key={sample.id} value={sample.id}>
                {sample.label}
              </option>
            ))}
          </optgroup>
        ))}
      </select>
    </div>
  );
}
