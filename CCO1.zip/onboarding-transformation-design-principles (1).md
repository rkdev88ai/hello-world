# Design Principles for Corporate Client Onboarding & Review Transformation

**Purpose:** These principles are the non-negotiable guardrails for every design decision in the onboarding and periodic review transformation — from target operating model and process redesign through to system architecture and vendor/build choices. Any design artifact (process map, service blueprint, data model, agent/workflow spec, UI mockup) should be traceable back to one or more of these principles. Where a proposed design conflicts with a principle, that conflict must be explicitly surfaced and arbitrated, not silently absorbed.

Organised into seven themes: Client Experience, Frontline & Employee Experience, Process, Data & Decisioning, Architecture & Technology, Risk/Compliance/Control, and Scale & Governance across 50+ markets.

---

## 1. Client Experience Principles

**1.1 One client, one relationship, one view — regardless of entity count or market.**
A global corporate with 40 legal entities across 15 markets should be onboarded and reviewed as *one relationship* with shared context, not 40 disconnected cases. Entity-level data collection should default to "collect once, reuse everywhere" within the client hierarchy.

**1.2 Ask once, never ask again.**
Any document, data point, or attestation already provided anywhere in the bank (this market, another market, another product, a prior review cycle) is pre-populated and offered for confirmation, not requested from scratch. Perpetual KYC (pKYC) means the client's data footprint compounds over time — it never resets to zero.

**1.3 Progressive, parallel, not sequential.**
Clients should never wait for one workstream (e.g. legal docs) to finish before another (e.g. account opening, product setup) can start. Design for maximum parallelism of independent workstreams, with a single orchestration layer resolving dependencies — not a client-facing relay race across departments.

**1.4 Radical transparency on status and next steps.**
At any moment, the client (and the RM) can see exactly what's done, what's outstanding, who owns the next action, and a realistic ETA. "Black box" case states (e.g. "in review") are a design failure, not an acceptable interim state.

**1.5 Channel and format flexibility, client's choice.**
Clients should be able to submit documents/data via portal, API/host-to-host, email-to-structured-intake, or in person with the RM — with equivalent turnaround regardless of channel. Don't force a large corporate treasury team onto a retail-style web form if they'd rather push data via API.

**1.6 Onboarding is the first product experience, not a pre-sales tax.**
The onboarding journey itself should showcase the bank's digital sophistication and network strength, since it is often the client's first substantive interaction after sales. A clunky onboarding undermines the "best network bank" positioning before the client has used a single product.

**1.7 Ready-to-transact / time-to-first-transaction is the primary objective.**
Every design decision is stress-tested against one question: does this reduce the elapsed time from "client says yes" to "client is ready to transact"? This is the primary objective the whole transformation is judged against — not a secondary nice-to-have alongside cost or control metrics, and not the cycle time of an internal case, but actual client-perceived time.

**1.8 The client is a bank-wide, transversal entity — not owned by any one market or business unit.**
A client's identity, relationship, and cumulative data/document footprint belong to the bank as a whole, not to the market or business unit that happened to originate the relationship. Any market or product team touching that client operates as a consumer/contributor to one shared, enterprise-wide client record — never a private local copy.

**1.9 Service on any device, from any location.**
Clients and staff should be able to pick up an onboarding/review task — reviewing status, submitting a document, approving a step — from whatever device and location they're on (desktop, mobile, a branch/office in another market), with full functionality and no "you must be on the office network/this specific machine" constraint. Design responsively and access-anywhere from the outset, not as a later mobile add-on.

---

## 2. Frontline & Employee Experience Principles

**2.1 The RM/CM is a relationship owner, not a form-chaser.**
Design out the work of RMs and Client Managers manually chasing documents, re-keying data across systems, or acting as a human API between client and operations. Their time should go to advisory and cross-sell conversations, not administrative relay.

**2.2 Confidence to cross-sell requires visible, trustworthy product-readiness signals.**
Frontline staff need a real-time, accurate view of "what can this client already do today" and "what's the fastest path to add product X" — so they can sell with confidence instead of avoiding conversations for fear of an onboarding nightmare they'll have to personally manage.

**2.3 One case, one accountable owner, always visible.**
Every in-flight onboarding/review case has a single named accountable owner at all times, visible to all stakeholders (client-facing and internal), even as work items move across specialist teams (KYC, credit, legal, tax, product). No case should ever be "everyone's and no one's."

**2.4 Operations staff are exception-handlers, not data-re-keyers.**
Design the system so that operations and KYC analysts spend their time on genuine judgement calls (ambiguous ownership structures, sanctions nuance, risk escalations) — not on transcription, chasing, or reconciling the same data across five systems. If a task is purely mechanical and rules-based, it should be automated, not routed to a human queue.

**2.5 Every handoff is a designed contract, not an email.**
Where work must cross from one team/specialism to another, the handoff is a structured, system-enforced contract (defined inputs required, defined outputs produced, defined SLA) — not an email, a shared spreadsheet, or a phone call to "check on this one."

**2.6 Make the right thing the easy thing.**
Compliant, complete, low-risk paths through the process should require the least effort from frontline staff. Where additional friction is unavoidable (e.g. high-risk client, complex ownership), that friction should be proportionate and clearly explained, not applied uniformly to everyone as blanket bureaucracy.

**2.7 Frontline feedback loops are structural, not occasional.**
The operating model includes a standing mechanism for frontline teams (RM, CM, Ops) to flag broken policy interpretations, bad data quality sources, or process dead-ends — and see them acted on in weeks, not years, via periodic "voice of frontline" governance forums tied to a backlog with committed SLAs.

---

## 3. Process Design Principles

**3.1 Design the target process before selecting or building the system.**
Systems and agents should be built to serve a deliberately (re)designed process and target operating model — not the reverse. Avoid "we bought/built platform X, now let's map our process onto it."

**3.2 Straight-through by default; human-in-the-loop by exception, not by default.**
Every step should ask: does this genuinely require human judgement (regulatory ambiguity, relationship sensitivity, novel risk pattern), or can it be automated end-to-end with human review only on exceptions/outliers? Default to automation; require an explicit justification for inserting a manual step.

**3.3 Case complexity should route dynamically, not follow one fixed path.**
A single-entity, low-risk, single-market onboarding and a 40-entity, multi-jurisdiction, high-risk group onboarding should never traverse the same fixed workflow. Design dynamic case orchestration that right-sizes the journey (steps, checks, approvals) to the actual complexity and risk profile of the case.

**3.4 Decouple policy/rules from process/workflow.**
Regulatory and credit policy changes (frequent, market-specific) should never require a workflow re-engineering exercise. Policy and rules live in a governed, versioned, machine-readable layer that the process/orchestration layer consumes — so a rule change is a configuration update, not a system change request.

**3.5 Reuse across onboarding and periodic review — one data/process backbone, two entry points.**
Periodic (or event-triggered) reviews are not a separate process built from scratch — they reuse the same client data model, document repository, policy engine, and orchestration backbone as initial onboarding, triggered by time, risk event, or product trigger rather than run as an isolated annual project.

**3.6 Design for the exception, but don't let the exception define the default path.**
Complex structures (trusts, funds, layered ownership, sanctioned-adjacent geographies) will always exist — design explicit, well-governed exception lanes for them, so their complexity doesn't leak into and slow down the 80% of vanilla cases.

**3.7 Every process step must justify its existence against risk, regulation, or client value.**
Legacy steps that exist "because that's how we've always done it" are removed unless they can be tied to a specific regulatory requirement, genuine risk mitigation, or client value. Historical process debt is not grandfathered in by default.

**3.8 Joining the bank is a separate lifecycle from adding or removing products.**
Becoming a client (establishing the relationship, entity, and baseline CDD) is a distinct process/lifecycle from adding, removing, or changing individual products and services against an already-onboarded client. A product add for an existing, current client should be a lightweight, product-specific journey — never require re-running full client onboarding, and never be conflated with it in the same case type.

---

## 4. Data & Decisioning Principles

**4.1 Golden source, single truth, everywhere consumed.**
Client static data, ownership structures, documents, and risk ratings have one authoritative golden source per data domain, consumed (not copied and diverged) by every downstream system — CRM, KYC platform, core banking, product systems.

**4.2 Data quality is captured at the point of origin, not cleaned up downstream.**
Validation, format, and completeness rules are enforced at first capture (client portal, RM input, API feed) — not discovered three systems later by an operations analyst doing manual QC.

**4.3 Explainability is mandatory for every automated decision.**
Any AI/rules-based decision that affects a client outcome (risk rating, approval, escalation, document request) must produce a human-readable rationale traceable to policy and data inputs — sufficient for an auditor, regulator, or client-facing employee to explain "why" without engineering support.

**4.4 Confidence-based automation, not all-or-nothing automation.**
Automated decisioning should carry a confidence/certainty signal; high-confidence outcomes flow straight through, low-confidence outcomes route to a human with the automation's reasoning attached as a head start — never a binary "fully automated" vs "fully manual" split.

**4.5 Data over documents and paper — always.**
Structured data, not the document or paper it came from, is the primary asset the bank operates on. Once a document is ingested and extracted, its structured data becomes the reusable, queryable, decisionable artefact; humans should rarely need to re-open the original PDF/scan except for genuine verification/dispute purposes, and no process step should require a human to manually read a document that has already been machine-extracted.

**4.6 Every data point has a lineage and a freshness/expiry rule.**
Client data and documents are tagged with source, capture date, and validity period, enabling perpetual KYC to trigger refresh only for what's actually stale — not blanket re-collection of everything at each review cycle.

**4.7 Provenance and explainability are non-negotiable.**
Every piece of client data and every decision must carry a clear, recoverable answer to "where did this come from" (provenance: source system/party, capture channel, capture date, transformation history) and "why was this decided" (explainability, per 4.3). Neither is an optional enhancement — a data point or decision that can't be traced to its origin and reasoning is not fit to drive a client outcome, an audit response, or a regulatory answer.

---

## 5. Architecture & Technology Principles

**5.1 Composable, API-first, modular over monolithic.**
Capabilities (screening, UBO resolution, document extraction, risk scoring, case orchestration) are built/bought as independently deployable, API-addressable modules — so any one component can be replaced or upgraded without a wholesale re-platform.

**5.2 Narrow, single-purpose components over broad, do-everything ones.**
Whether classic services or AI agents, prefer many narrowly-scoped, well-tested components with clear inputs/outputs over a small number of broad, opaque components — improving reliability, testability, and the ability to reason about failure.

**5.3 Design for 50+ market variation as a first-class concern, not an afterthought.**
The architecture assumes country-specific regulatory deltas, language, document types, and local system integrations from day one — via a configurable country-overlay layer on top of a common global core — rather than retrofitting localisation onto a design built for one market.

**5.4 Cloud-native, elastic, and event-driven.**
The platform scales elastically with onboarding volume peaks (e.g. post-campaign surges) and reacts to events (new document received, sanctions list update, ownership change) in near real time, rather than relying on batch cycles that reintroduce latency.

**5.5 Build vs. buy vs. reuse — decided per capability, not for the whole platform.**
Commoditised capability (e.g. sanctions screening, document OCR) should generally be bought/leveraged from best-in-class providers; genuinely differentiating capability (e.g. the orchestration/decisioning layer that embodies the bank's target operating model) is where build effort concentrates.

**5.6 Security, resilience, and observability designed in, not bolted on.**
Every component is designed from the outset with access control, encryption, audit logging, resilience (graceful degradation, no single points of failure for a global 50+ market platform), and end-to-end observability of case status and system health.

**5.7 Human-AI collaboration is designed at the interface level, not just the backend.**
Wherever AI/automation makes a recommendation or decision, the UI/UX for the human reviewer is explicitly designed (what they see, what they can override, how overrides are captured and fed back to improve the system) — not an afterthought bolted onto an existing screen.

**5.8 Prefer global over local — local is the exception that must justify itself.**
The default answer to "should this capability/rule/system be global or market-specific" is global. A market may deviate only where local regulation, language, or genuinely local product structures require it — and that deviation is scoped as a deliberate, minimal overlay on the global core (see 5.3, 6.4, 7.1), not a parallel local build.

**5.9 Horizontal identity, vertical entitlements.**
A client's (and a staff member's) identity is one horizontal construct, shared and consistent across every market, product, and system it touches. Entitlements — what a given user or system can see or do with that identity — are applied vertically, scoped per product, market, or role. Never solve access/permission problems by fragmenting the identity itself into multiple disconnected local copies.

**5.10 Decouple from external data and utility providers.**
The platform integrates with external data/utility providers (registries, sanctions/PEP lists, KYC utilities, credit bureaus, ownership-data vendors) through an abstraction layer, not direct point-to-point dependencies. Switching or adding a provider should be a configuration/integration change behind the abstraction layer, never a redesign of the core platform or the processes that consume that data.

**5.11 Prefer consistency over availability for client, risk, and entitlement data.**
Where a genuine trade-off exists (per the CAP theorem, in a distributed, multi-market architecture), the platform favours strong consistency over maximum availability for data that drives risk decisions, entitlements, and client records — a temporarily unavailable but consistent system is preferable to a fully available system that risks stale or conflicting client/risk data across markets.

---

## 6. Risk, Compliance & Control Principles

**6.1 Risk-based, proportionate, not uniformly maximal.**
Controls and friction scale with actual client/relationship risk (jurisdiction, ownership complexity, product risk, sanctions exposure) — not applied at a uniform "maximum caution" level to every client regardless of risk profile.

**6.2 Control effectiveness is evidenced continuously, not reconstructed for audit.**
The platform generates audit-ready evidence (who decided what, when, on what basis) as a natural byproduct of normal operation — not as a separate, painful reconstruction exercise every time internal audit or a regulator asks.

**6.3 Four-eyes and segregation of duties are enforced by the system, not by manual discipline.**
Wherever dual control or segregation of duties is a regulatory or policy requirement, the workflow enforces it structurally (system prevents self-approval, prevents skipping a required check) rather than relying on staff to remember and comply.

**6.4 Global policy sets the floor; local regulation can only raise the bar.**
The design assumes a global minimum standard for KYC/onboarding rigor, with country overlays permitted only to add stricter local requirements — never to create a silent, undocumented weaker path in a given market.

**6.5 Change to policy or regulation is a controlled, versioned event.**
Every policy/rule change is versioned, dated, and traceable — so that a case processed under an old rule set can still be defended, and the platform can prove which rule version applied to which decision at which point in time.

**6.6 Customer Due Diligence is continual, not periodic.**
CDD/KYC is designed as an always-on, event- and risk-triggered process (perpetual KYC) rather than a point-in-time exercise repeated on a fixed calendar (e.g. "every 1/3/5 years"). Triggers include ownership changes, adverse media, sanctions list updates, transaction-behaviour anomalies, and data staleness (per 4.6) — with the fixed-cycle review becoming a backstop for clients with no other trigger, not the primary mechanism.

---

## 7. Scale, Governance & Change Principles

**7.1 One target operating model, adapted — not 50 independent local models.**
A single global target operating model and platform is the default; market-specific adaptation is deliberate, governed, and minimal — not the accidental byproduct of 50 markets each solving onboarding their own way.

**7.2 Design principles are arbitration tools, not slogans.**
When two principles appear to conflict in a specific design decision (e.g. "ask once" vs. a local regulator's insistence on re-verification), that conflict is explicitly raised to a named governance forum for a documented decision — not silently resolved by whoever is in the room.

**7.3 Measure what clients and frontline actually feel, not just internal cycle time.**
Success metrics include client-perceived time-to-value, RM/CM confidence/satisfaction, and cross-sell conversion — not solely internal case-cycle-time or cost-per-case metrics that can improve while the client/frontline experience stays broken.

**7.4 Incremental, value-proven rollout over big-bang transformation.**
The platform is proven on a bounded scope (a market, a client segment, or a product line) with measurable outcomes before wider rollout — reducing the risk of a multi-year, multi-market programme discovering fundamental design flaws only at the end.

**7.5 Change management and adoption are designed with the same rigor as the technology.**
RM/CM/Ops training, incentive alignment, and communication are treated as first-class workstreams with dedicated design effort and success metrics — not an afterthought bolted onto a go-live checklist.

**7.6 Build for continuous evolution, not a fixed end-state.**
The target operating model and platform are designed assuming ongoing regulatory change, new products, and new markets — with clear extension points — rather than as a project with a fixed finish line after which the design is expected to remain static.

---

## How to use these principles

- **At design review:** every process map, architecture decision record, or agent/workflow spec should reference which principles it satisfies, and flag any it knowingly trades off (with rationale).
- **At governance forums:** use section 7.2 as the mechanism for resolving principle conflicts — don't let them get resolved informally by whoever raises the loudest objection.
- **As a scorecard:** consider scoring major design options (e.g. build vs. buy decisions, target process variants) against these principles as a structured comparison, rather than relying purely on qualitative debate.
