# Conceptual Architecture — Detailed Write-Up
### Client Onboarding & Lifecycle Platform

This write-up expands each block of the conceptual architecture diagram, then goes deeper on the two questions that matter most for a platform that has to survive 50+ markets of regulatory change: **how the design absorbs constant policy change**, and **how the data model absorbs constant attribute growth** — without either forcing a re-platform.

---

## 1. Design-time capabilities

Design time is where humans (policy owners, product owners, architects) shape what the run-time platform is allowed to do. Nothing here touches a live case; everything here produces a versioned, testable artefact that run time later consumes.

### 1.1 Journey & agentic workflow design
This is where a journey (e.g. "onboard a large corporate with 3 entities in 2 markets") is composed from reusable building blocks — not hand-coded per case type. A journey definition declares *which* orchestration steps apply, *which* agents/services fulfil each step, and *what* data/decisions gate progression — but not the business rules themselves (those live in the policy layer, section 2). Practically, this is a visual or DSL-based journey composer: architects assemble journeys from a library of certified steps (KYC check, tax validation, credit approval, account provisioning), and the composer validates that every step's inputs are satisfiable from what a prior step produces, before the journey can even be submitted for testing.

### 1.2 Policy & rules authoring
The Digital Policy Engine's authoring surface. Policy owners (compliance, tax, credit, product) write rules in a declarative, business-readable form — decision tables, rule DSL, or a structured Q&A wizard — rather than code. A single global rule set is authored once; country-specific deltas are authored as *overlays* that only add or tighten conditions (per Design Principle 6.4 and 5.8 — global is the default, local is the justified exception). Every rule change is drafted, diffed against the current published version, and routed for approval before it can be scheduled for release. This section is covered in depth in section 6.

### 1.3 Data model, schema & mastering design
Where the canonical data model — the shape of "client," "entity," "product holding," "ownership relationship" — is defined and evolved. This is not a one-time ERD exercise: it's a living, versioned schema with an explicit change process for adding attributes, entities, and relationships as new regulatory or product requirements emerge (section 7 goes deep on this). Mastering rules — which source wins when two systems disagree on the same attribute, how conflicts are flagged, how survivorship is decided — are authored here as declarative rules, the same way policy rules are, so a change to "which system is golden for legal name" is a configuration change, not a code change.

### 1.4 Agent skill & capability registry
A catalogue of every narrow, single-purpose agent/service available to journeys and orchestration (per the earlier design principle of many narrow skills over few broad ones): a UBO-resolution agent, a document-classification agent, a sanctions-match-adjudication agent, and so on. Each entry declares its exact input/output contract, its confidence-reporting behaviour, its data residency constraints, and its owning team. Orchestration and journey design (1.1) can only reference agents that exist in this registry — nothing is wired ad hoc — which is what makes the platform's blast radius and resolvability properties (sections 6 of the earlier design-principles document; also 8.4/8.5 below) enforceable rather than aspirational.

### 1.5 Test, simulation & regression harness
Every change coming out of 1.1–1.4 — a new journey, a new or amended rule, a new attribute or mastering rule, a new agent version — is run through a synthetic and historical-replay test suite before it's eligible for publish. Regression means literally re-running yesterday's real (anonymised) cases against today's proposed rule set and diffing the outcomes: if 40 cases that used to pass would now fail, or vice versa, that's surfaced to the policy owner *before* release, not discovered in production. This harness is the thing that makes frequent policy change safe rather than reckless (see section 6.3).

**Approval gates**: business, compliance, and (where required) a governance committee sign off on the diffed, tested change before it can move to the publish gate. This is a structured workflow with its own audit trail — not a meeting.

---

## 2. Versioned publish gate

Every artefact — policy/rule set, journey definition, data model version, mastering rule set, agent registry entry — is versioned independently, but released together as a coherent, dated **platform configuration version**. This gate is the single place where "what changed, who approved it, when does it take effect" is recorded immutably. Two properties matter here:

- **Point-in-time reconstructability**: any case processed last Tuesday can be re-explained today using the exact rule/data-model version that was live last Tuesday, even though the platform has since moved through several newer versions. This is what makes audits and regulator questions answerable without a special reconstruction project.
- **Staged rollout, not big-bang**: a new version doesn't have to go live everywhere at once. It can be released to a single market, a single client segment, or a shadow/canary population first — running in parallel with the current version and compared — before wider rollout. This directly serves the "incremental, value-proven rollout" principle and gives policy owners a safe way to test a change's real-world effect before committing the whole bank to it.

---

## 3. Run-time capabilities

### 3.1 Control tower / single pane of glass
The run-time observability and case-management surface for RMs, ops, and governance — one place to see any case's status, any exception awaiting a human, and platform health, regardless of which market or product the case belongs to (this is the "single client, single view" and "radical transparency" principles made operational). It is also where a human picks up an exception the orchestration engine has routed to them, with the machine's reasoning already attached.

### 3.2 Channels & client interaction
The intake layer — portal, RM-assisted entry, API/host-to-host feeds from large corporate treasuries — normalised into a common intake format before anything downstream sees it. This is deliberately kept thin: its only job is capture and light validation at the point of origin (per the data-quality-at-origin principle); it holds no business logic of its own.

### 3.3 Orchestration engine
Executes the journey defined at design time: sequences steps, runs independent steps in parallel, tracks case state, and calls out to the policy decision point and the agent registry as each step requires. Critically, the orchestration engine contains **no embedded business rules** — it asks the policy decision point "is this client's ownership structure acceptable" and acts on the answer, but it does not itself encode what "acceptable" means. That separation is what lets policy change independently of orchestration (section 6).

### 3.4 Policy decision point (PDP)
The run-time evaluation service: given a case's current data and the applicable policy version, it returns a decision (pass/fail/refer) plus the rule trail that produced it. It is intentionally a narrow, stateless, deterministic service — same inputs and same policy version always produce the same output — which is what makes it auditable, testable, and safely swappable independent of everything around it.

### 3.5 Data mastering & resolution engine
Continuously resolves the golden version of every client attribute from potentially conflicting sources (client-submitted, RM-entered, external registry, prior review), applying the survivorship rules authored at design time (1.3), and exposes one authoritative "current state of this client" to every consumer. It also carries the freshness/expiry metadata that drives perpetual KYC — flagging exactly which attributes are stale and need refresh, rather than treating the whole client record as due for renewal.

### 3.6 Core KYC, screening & provisioning
The regulated decisioning and execution capabilities — screening against sanctions/PEP/adverse media, risk rating, and the downstream account/product provisioning that actually makes the client ready to transact. These consume the PDP's decisions and the mastering engine's golden data; they do not re-implement policy or re-resolve data themselves.

### 3.7 Event & trigger bus
The nervous system connecting everything above: a new document arriving, a sanctions list update, an ownership change reported by a registry, a transaction pattern anomaly — each is an event that can trigger orchestration to re-open a review, re-run screening, or request refreshed data, without waiting for a scheduled cycle. This is the mechanical enabler of "continual CDD" (section 6.6 of the design principles) and is also the platform's single largest blast-radius concern (section 8.5).

### 3.8 Human-in-the-loop exception queues
Attached directly to the orchestration engine and the PDP: whenever either produces a low-confidence or policy-flagged outcome, the case (with full machine reasoning attached) routes to a queue a suitably skilled analyst can act on — rather than stalling silently or auto-approving.

---

## 4. Governance, compliance approvals & monitoring / observability

Sits across the whole platform rather than at one point in the flow: business, compliance, and committee approvals (for cases the PDP refers up); technical observability (latency, error rates, throughput per capability); and — equally important — **business activity monitoring**: live dashboards on the metrics that actually matter to the RTT objective (cases in flight by stage, time-to-ready-to-transact by segment, exception queue age, cross-sell conversion post-onboarding). Section 8.7 goes deeper on why both halves of observability are treated as one capability, not two.

---

## 5. How the numbered considerations map onto this

| # | Consideration | Where it lands and why |
|---|---|---|
| 1 | Agents acting on behalf of humans | Orchestration engine (executes on delegated authority) and agent skill registry (declares what each agent may act on and how its actions are attributed) |
| 2 | Control simplification, determinism, declarative | Policy authoring and the PDP — rules are declarative and evaluation is deterministic by design, never left to a probabilistic model where a regulatory outcome is at stake |
| 3 | Data sovereignty & residency | Data model design (where residency constraints are declared per attribute) and the mastering engine (where a regional golden copy is resolved without exporting data outside its permitted zone) |
| 4 | Resolvability & separability | An architecture-wide property carried by the API/event contracts between every block above — not owned by any single box |
| 5 | Blast radius | The event & trigger bus — the highest-fanout component, and therefore the one requiring the most deliberate containment |
| 6 | Performance | Orchestration engine — the component most sensitive to latency because it sits on the client's critical path |
| 7 | Observability | Control tower and the governance/monitoring band — technical and business views of the same underlying telemetry |

---

## 6. Deep dive — designing for constant policy change

Policy in a 50+ market bank does not change occasionally; it changes continuously — a regulator issues a circular, a tax treaty is amended, an internal risk appetite shifts, a new sanctions regime is announced. A platform that treats a policy change as a development project has already failed at scale. The design addresses this in five concrete ways:

**6.1 Policy is data, not code.** Every rule — "flag if beneficial ownership exceeds 25% and jurisdiction is on list X," "require enhanced due diligence for this client type" — is expressed in a declarative rule format (decision tables, a rules DSL, or structured conditions) that the PDP interprets at run time. A rule change is authored, tested, and published without a single line of orchestration or agent code being touched, without a service redeploy, and without a release train. This is the single biggest lever for change velocity: the gap between "regulator issues new requirement" and "platform enforces it" shrinks from a multi-sprint engineering change to a policy-authoring and approval cycle.

**6.2 Global core, local overlay.** A rule is authored once at the global level and applies everywhere by default. A market only authors a delta where its regulator genuinely requires something stricter or different — and that delta is scoped, visible, and owned by that market's compliance function, not buried in a market-specific codebase. This means a global policy change (e.g. a new global sanctions screening standard) propagates to all 50+ markets simultaneously by default, while a market-specific change (e.g. a local tax ID format) never leaks into or complicates any other market's rule set.

**6.3 Every change is tested against real history before it's live.** The regression harness (1.5) re-runs the proposed rule set against a representative sample of recent real cases and shows the policy owner exactly what would change — which previously-passing clients would now be flagged, and vice versa — before approval. This converts "will this rule change have an unintended side effect" from a production incident into a pre-release finding, which is what makes frequent change *safe* rather than merely *fast*.

**6.4 Versioned, staged, reversible.** Because every policy version is independently versioned and releases can be staged to a market or segment before wider rollout, a policy owner can trial a change on a small population, observe its real effect through the business activity monitoring layer, and either proceed or roll back — without that decision being irreversible or all-or-nothing. Rollback is a version pointer change, not a re-deployment.

**6.5 One rule engine, many consumers, no duplication.** Because the PDP is a single, narrow, stateless service that orchestration, screening, and any future capability all call into, a policy change takes effect everywhere it's relevant the moment it's published — there is no risk of one downstream system running on an old copy of the rule because rules were never copied into multiple places to begin with.

The net effect: policy change moves from being an engineering-led, quarterly-cadence activity to a compliance-led, near-continuous one — which is precisely what a bank facing constant regulatory change in 50+ markets needs.

---

## 7. Deep dive — a data model that absorbs constant attribute growth

The single most common way enterprise data platforms ossify is a canonical model that requires a schema migration — and therefore an engineering project — every time the business needs one new attribute (a new ESG disclosure field, a new tax reporting element, a new product-specific KYC data point). The design avoids this through four mechanisms working together:

**7.1 A stable core, an extensible shell.** The canonical model has a small, deliberately stable core of universal attributes (legal name, incorporation jurisdiction, entity type, relationship identifiers) that changes rarely, and a much larger, explicitly extensible attribute space for everything else. New attributes are added to the extensible shell as configuration — a metadata registration, not a schema migration — while the stable core stays untouched. This is the practical reason a "policy-aligned data model" (as the consultant's landscape frames it) matters: the extensible shell's growth is driven directly by what policy declares it needs, not by ad hoc requests.

**7.2 Attribute definitions carry their own metadata.** Every attribute in the shell is registered with its own type, valid values, sourcing rule (which system is authoritative), sensitivity classification, jurisdictional applicability (which markets/regulations require it), residency constraint, and freshness/expiry rule. Adding "beneficial ownership percentage disclosure under regulation Y" is: register the attribute with these properties, declare which source system(s) can supply it, and declare the mastering/survivorship rule if more than one can. No downstream consumer's code needs to change to become aware of it — a consumer either declares interest in the new attribute (and starts receiving it) or ignores it, because the schema registry contract is additive by construction.

**7.3 Additive, backward-compatible schema evolution as a hard rule.** The schema registry enforces that changes are additive (new optional attributes, new entity types, new relationship types) rather than breaking (renaming or removing an attribute a consumer already depends on, changing a type). A breaking change is handled as a new version with an explicit, time-bounded migration path for consumers — never a silent in-place change that could break a downstream system that wasn't touched as part of the release. This is what lets 50+ markets and dozens of downstream consumers evolve independently rather than needing a synchronised "big bang" migration every time one market needs a new field.

**7.4 Storage decoupled from schema rigidity.** The operational data store underneath the canonical model is built to hold flexible, semi-structured attribute sets (rather than a rigid, wide relational table that requires a DDL migration for every new column) while the schema registry provides the typing, validation, and governance layer on top. Practically: adding an attribute is a registry entry plus a mastering rule, not a database migration, an index rebuild, or a coordinated release across every service that touches the client record.

**7.5 The data model design step is where policy attribute demand lands first.** Because the data model, schema & mastering design (1.3) sits directly design-time-adjacent to policy & rules authoring (1.2), a new policy requirement that implies a new data point flows into a defined intake: policy owner specifies the new requirement → data model owner registers the attribute (7.2) → mastering rule is authored for it → the regression harness (1.5) confirms nothing existing breaks → it's released through the same versioned publish gate as any other change. There is one front door for "policy needs a new data point," not an ad hoc request landing on whichever engineering team is available.

The net effect: the data model's growth rate is decoupled from the platform's release cadence. A new regulatory data point, ESG disclosure field, or product-specific attribute is a metadata and mastering-rule change measured in days, not a schema migration measured in a quarter — and it doesn't force every one of the 50+ markets' systems to move in lockstep to adopt it.
