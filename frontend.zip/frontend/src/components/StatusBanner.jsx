import { useEffect, useState } from 'react';

const STEPS = [
  'Planning risk-oriented search queries…',
  'Searching public sources for the entity…',
  'Extracting associated parties from the evidence…',
  'Screening associated parties independently…',
  'Assessing findings and computing the risk score…',
  'Rendering the report…'
];

export default function StatusBanner({ mode, message }) {
  const [stepIndex, setStepIndex] = useState(0);

  useEffect(() => {
    if (mode !== 'loading') return undefined;
    setStepIndex(0);
    const interval = setInterval(() => {
      setStepIndex((i) => Math.min(i + 1, STEPS.length - 1));
    }, 3500);
    return () => clearInterval(interval);
  }, [mode]);

  if (mode === 'idle') return null;

  if (mode === 'error') {
    return (
      <div className="status-banner status-banner--error">
        <strong>Screening failed.</strong> {message}
      </div>
    );
  }

  return (
    <div className="status-banner status-banner--loading">
      <span className="status-spinner" aria-hidden="true" />
      {STEPS[stepIndex]}
    </div>
  );
}
