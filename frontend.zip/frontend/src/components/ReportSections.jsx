import Badge from './Badge';

const OVERALL_RESULT_META = {
  no_material_adverse_information_identified: { color: 'green', label: 'No material adverse information identified' },
  inconclusive: { color: 'gray', label: 'Inconclusive' },
  adverse_information_found: { color: 'amber', label: 'Adverse information found' },
  potential_match_found: { color: 'red', label: 'Potential match found' }
};

export function SummarySection({ assessment, requestMeta, resultCount }) {
  const meta = OVERALL_RESULT_META[assessment.overall_result] || { color: 'gray', label: assessment.overall_result };
  return (
    <div className="report-section">
      <div className="summary-header">
        <div>
          <div className="summary-eyebrow">Overall automated result</div>
          <Badge color={meta.color}>{meta.label}</Badge>
        </div>
        <dl className="summary-meta">
          <dt>Entity</dt>
          <dd>{assessment.entity_reviewed}</dd>
          <dt>Location</dt>
          <dd>{assessment.location}</dd>
          <dt>Review period</dt>
          <dd>{assessment.period_reviewed}</dd>
          <dt>Provider</dt>
          <dd>{requestMeta.provider === 'serpapi' ? 'SerpAPI (Google)' : 'SearXNG (self-hosted)'}</dd>
          <dt>Records reviewed</dt>
          <dd>{resultCount}</dd>
        </dl>
      </div>
      <h3>Executive summary</h3>
      <p className="summary-text">{assessment.executive_summary}</p>
    </div>
  );
}

export function FindingsSection({ findings }) {
  if (!findings.length) {
    return (
      <div className="report-section">
        <p className="empty-state">No material finding was generated from the supplied search-result evidence.</p>
      </div>
    );
  }

  return (
    <div className="report-section">
      {findings.map((finding, index) => (
        <article key={index} className={`finding-card finding-card--${finding.color}`}>
          <div className="finding-card-header">
            <Badge color={finding.color}>{finding.category.replace(/_/g, ' ')}</Badge>
            <span className="finding-status">{finding.status.replace(/_/g, ' ')}</span>
            <span className="finding-risk">{finding.risk_level.replace(/_/g, ' ')} risk</span>
          </div>
          <h4>{finding.headline}</h4>
          <div className="finding-meta">
            <span>
              <strong>Entity/party:</strong> {finding.entity_or_party}
            </span>
            {finding.event_date && (
              <span>
                <strong>Date:</strong> {finding.event_date}
              </span>
            )}
            <span>
              <strong>References:</strong>{' '}
              {finding.references.length ? finding.references.map((r) => `[${r}]`).join(' ') : 'None'}
            </span>
          </div>
          <p>{finding.summary}</p>
          <p className="finding-rationale">
            <strong>Assessment rationale:</strong> {finding.rationale}
          </p>
        </article>
      ))}
    </div>
  );
}

export function PartiesSection({ parties }) {
  if (!parties.length) {
    return (
      <div className="report-section">
        <p className="empty-state">No associated parties were reliably extracted from the search-result evidence.</p>
      </div>
    );
  }

  const confidenceColor = { high: 'green', medium: 'amber', low: 'gray' };

  return (
    <div className="report-section">
      <table className="report-table">
        <thead>
          <tr>
            <th>Name</th>
            <th>Relationship</th>
            <th>Confidence</th>
            <th>Supporting evidence</th>
          </tr>
        </thead>
        <tbody>
          {parties.map((party, index) => (
            <tr key={index}>
              <td>{party.name}</td>
              <td>{party.relationship}</td>
              <td>
                <Badge color={confidenceColor[party.confidence] || 'gray'}>{party.confidence}</Badge>
              </td>
              <td>
                {party.evidence}
                {party.source_urls?.length > 0 && (
                  <div className="source-links">
                    {party.source_urls.map((url) => (
                      <a key={url} href={url} target="_blank" rel="noreferrer">
                        {url}
                      </a>
                    ))}
                  </div>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export function SourcesSection({ citations }) {
  if (!citations.length) {
    return (
      <div className="report-section">
        <p className="empty-state">No source references were returned.</p>
      </div>
    );
  }

  return (
    <div className="report-section">
      <ol className="sources-list">
        {citations.map((citation) => (
          <li key={citation.reference_number} id={`reference-${citation.reference_number}`}>
            <div className="source-title">
              [{citation.reference_number}] {citation.title}
            </div>
            <div className="source-details">
              <span>{citation.source || 'Source not supplied'}</span>
              {citation.published_date && <span> · {citation.published_date}</span>}
            </div>
            <a href={citation.url} target="_blank" rel="noreferrer" className="source-url">
              {citation.url}
            </a>
          </li>
        ))}
      </ol>
    </div>
  );
}

export function MethodologySection({ searchPlan, provider }) {
  const queries = searchPlan?.queries || [];
  return (
    <div className="report-section">
      <p>
        The search agent generated risk-oriented queries and submitted them via{' '}
        <strong>{provider === 'serpapi' ? 'SerpAPI (Google)' : 'SearXNG (self-hosted metasearch)'}</strong>. Result
        metadata was deduplicated before analysis by the reporting agent.
      </p>
      <h3>Queries executed</h3>
      <ul className="query-list">
        {queries.map((q, index) => (
          <li key={index}>
            <code>{q.query}</code>
            <span className="query-purpose"> — {q.purpose}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

export function LimitationsSection({ limitations, errors }) {
  return (
    <div className="report-section">
      <ul className="limitations-list">
        {limitations.map((limitation, index) => (
          <li key={index}>{limitation}</li>
        ))}
      </ul>

      {errors?.length > 0 && (
        <>
          <h3>Technical exceptions</h3>
          <ul className="limitations-list limitations-list--error">
            {errors.map((error, index) => (
              <li key={index}>{error}</li>
            ))}
          </ul>
        </>
      )}

      <p className="system-classification">
        <strong>System classification:</strong> Decision support only. This report must not be used as the sole
        basis for customer rejection, account closure, sanctions escalation or regulatory reporting.
      </p>
    </div>
  );
}
