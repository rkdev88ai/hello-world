const OPTIONS = [
  { id: 'serpapi', label: 'SerpAPI', hint: 'Google, via SerpAPI' },
  { id: 'searxng', label: 'SearXNG', hint: 'Self-hosted metasearch' }
];

export default function ProviderToggle({ value, onChange, disabled }) {
  return (
    <div className="provider-toggle" role="radiogroup" aria-label="Search provider">
      {OPTIONS.map((option) => (
        <button
          key={option.id}
          type="button"
          role="radio"
          aria-checked={value === option.id}
          disabled={disabled}
          className={`provider-toggle-option${value === option.id ? ' active' : ''}`}
          onClick={() => onChange(option.id)}
        >
          <span className="provider-toggle-label">{option.label}</span>
          <span className="provider-toggle-hint">{option.hint}</span>
        </button>
      ))}
    </div>
  );
}
