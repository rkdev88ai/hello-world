import { useState } from 'react';
import ProviderToggle from './ProviderToggle';

export default function EntityForm({ onSubmit, isLoading }) {
  const [companyName, setCompanyName] = useState('');
  const [location, setLocation] = useState('');
  const [lookbackYears, setLookbackYears] = useState(2);
  const [provider, setProvider] = useState('serpapi');

  const canSubmit = companyName.trim().length >= 2 && location.trim().length >= 2 && !isLoading;

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!canSubmit) return;
    onSubmit({ companyName: companyName.trim(), location: location.trim(), lookbackYears, provider });
  };

  return (
    <form className="entity-form" onSubmit={handleSubmit}>
      <div className="entity-form-row">
        <label htmlFor="company-name">Entity name</label>
        <input
          id="company-name"
          type="text"
          placeholder="e.g. Acme Trading Pte Ltd"
          value={companyName}
          onChange={(e) => setCompanyName(e.target.value)}
          disabled={isLoading}
          required
          minLength={2}
        />
      </div>

      <div className="entity-form-row">
        <label htmlFor="location">Location</label>
        <input
          id="location"
          type="text"
          placeholder="e.g. Singapore"
          value={location}
          onChange={(e) => setLocation(e.target.value)}
          disabled={isLoading}
          required
          minLength={2}
        />
      </div>

      <div className="entity-form-row entity-form-row--inline">
        <label htmlFor="lookback">Lookback period</label>
        <select
          id="lookback"
          value={lookbackYears}
          onChange={(e) => setLookbackYears(Number(e.target.value))}
          disabled={isLoading}
        >
          {[1, 2, 3, 5, 7, 10].map((years) => (
            <option key={years} value={years}>
              {years} {years === 1 ? 'year' : 'years'}
            </option>
          ))}
        </select>
      </div>

      <div className="entity-form-row">
        <label>Search provider</label>
        <ProviderToggle value={provider} onChange={setProvider} disabled={isLoading} />
      </div>

      <button type="submit" className="btn-primary" disabled={!canSubmit}>
        {isLoading ? 'Screening…' : 'Run screening'}
      </button>
    </form>
  );
}
