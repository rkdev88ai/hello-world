import { useState } from 'react';
import RiskGauge from './RiskGauge';
import {
  SummarySection,
  FindingsSection,
  PartiesSection,
  SourcesSection,
  MethodologySection,
  LimitationsSection
} from './ReportSections';

const TABS = [
  { id: 'summary', label: 'Summary' },
  { id: 'findings', label: 'Findings' },
  { id: 'parties', label: 'Associated parties' },
  { id: 'sources', label: 'Sources' },
  { id: 'methodology', label: 'Methodology' },
  { id: 'limitations', label: 'Limitations' }
];

function downloadMarkdown(markdown, entityName) {
  const blob = new Blob([markdown], { type: 'text/markdown' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  const safeName = entityName.replace(/[^A-Za-z0-9_-]+/g, '_').replace(/^_+|_+$/g, '');
  a.href = url;
  a.download = `${safeName || 'screening'}_report.md`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

export default function ReportView({ result }) {
  const [activeTab, setActiveTab] = useState('summary');

  const { assessment, risk, citations, search_plan: searchPlan, errors, request, result_count: resultCount } = result;

  const tabCounts = {
    findings: assessment.findings.length,
    parties: assessment.associated_parties.length,
    sources: citations.length
  };

  return (
    <div className="report-view">
      <aside className="report-sidebar">
        <RiskGauge score={risk?.score} band={risk?.band} label={risk?.label} />
        <div className="sidebar-entity">
          <div className="sidebar-entity-name">{assessment.entity_reviewed}</div>
          <div className="sidebar-entity-meta">{assessment.location}</div>
        </div>
        <button type="button" className="btn-secondary" onClick={() => downloadMarkdown(result.markdown_report, assessment.entity_reviewed)}>
          Download full report (.md)
        </button>
      </aside>

      <div className="report-main">
        <nav className="report-tabs">
          {TABS.map((tab) => (
            <button
              key={tab.id}
              type="button"
              className={`report-tab${activeTab === tab.id ? ' active' : ''}`}
              onClick={() => setActiveTab(tab.id)}
            >
              {tab.label}
              {typeof tabCounts[tab.id] === 'number' && <span className="report-tab-count">{tabCounts[tab.id]}</span>}
            </button>
          ))}
        </nav>

        <div className="report-content">
          {activeTab === 'summary' && (
            <SummarySection assessment={assessment} requestMeta={request} resultCount={resultCount} />
          )}
          {activeTab === 'findings' && <FindingsSection findings={assessment.findings} />}
          {activeTab === 'parties' && <PartiesSection parties={assessment.associated_parties} />}
          {activeTab === 'sources' && <SourcesSection citations={citations} />}
          {activeTab === 'methodology' && <MethodologySection searchPlan={searchPlan} provider={request.provider} />}
          {activeTab === 'limitations' && <LimitationsSection limitations={assessment.limitations} errors={errors} />}
        </div>
      </div>
    </div>
  );
}
