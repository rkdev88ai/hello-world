const CX = 120;
const CY = 120;
const RADIUS = 96;
const BANDS = [
  { from: 0, to: 34, color: 'var(--risk-green)' },
  { from: 34, to: 67, color: 'var(--risk-amber)' },
  { from: 67, to: 100, color: 'var(--risk-red)' }
];

function scoreToAngleDeg(score) {
  // 0 -> 180deg (pointing left), 100 -> 0deg (pointing right)
  return 180 * (1 - score / 100);
}

function polarPoint(radius, angleDeg) {
  const rad = (angleDeg * Math.PI) / 180;
  return {
    x: CX + radius * Math.cos(rad),
    y: CY - radius * Math.sin(rad)
  };
}

function arcPath(fromScore, toScore, radius) {
  const startAngle = scoreToAngleDeg(fromScore);
  const endAngle = scoreToAngleDeg(toScore);
  const start = polarPoint(radius, startAngle);
  const end = polarPoint(radius, endAngle);
  const largeArcFlag = startAngle - endAngle > 180 ? 1 : 0;
  return `M ${start.x} ${start.y} A ${radius} ${radius} 0 ${largeArcFlag} 1 ${end.x} ${end.y}`;
}

export default function RiskGauge({ score, band, label }) {
  const hasScore = typeof score === 'number';
  const displayScore = hasScore ? score : 0;
  const needleAngle = scoreToAngleDeg(displayScore);
  const needleTip = polarPoint(RADIUS - 18, needleAngle);

  return (
    <div className="risk-gauge">
      <svg viewBox="0 0 240 150" className="risk-gauge-svg" role="img" aria-label={`Risk score ${displayScore} of 100`}>
        {BANDS.map((b) => (
          <path
            key={b.from}
            d={arcPath(b.from, b.to, RADIUS)}
            fill="none"
            stroke={b.color}
            strokeWidth={18}
            strokeLinecap="butt"
          />
        ))}

        {/* Tick labels */}
        <text x={polarPoint(RADIUS + 20, 180).x} y={polarPoint(RADIUS + 20, 180).y + 4} className="risk-gauge-tick">
          0
        </text>
        <text x={polarPoint(RADIUS + 24, 90).x} y={polarPoint(RADIUS + 24, 90).y} className="risk-gauge-tick" textAnchor="middle">
          50
        </text>
        <text x={polarPoint(RADIUS + 20, 0).x} y={polarPoint(RADIUS + 20, 0).y + 4} className="risk-gauge-tick" textAnchor="end">
          100
        </text>

        {hasScore && (
          <g className="risk-gauge-needle">
            <line x1={CX} y1={CY} x2={needleTip.x} y2={needleTip.y} stroke="var(--navy)" strokeWidth={4} strokeLinecap="round" />
            <circle cx={CX} cy={CY} r={8} fill="var(--navy)" />
          </g>
        )}
      </svg>

      <div className="risk-gauge-readout">
        <div className={`risk-gauge-score risk-gauge-score--${band || 'pending'}`}>
          {hasScore ? displayScore : '—'}
        </div>
        <div className="risk-gauge-label">{label || 'Run a screening to see the risk score'}</div>
      </div>
    </div>
  );
}
