export default function Header() {
  return (
    <header className="app-header">
      <div className="app-header-title">
        <span className="app-header-eyebrow">CIB · Financial Crime Screening</span>
        <h1>Adverse Media &amp; Sanctions Screening</h1>
      </div>
    </header>
  );
}
