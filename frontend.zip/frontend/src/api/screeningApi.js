// The Vite dev server proxies /api to the FastAPI backend (see vite.config.js),
// and a production static build should be served behind the same proxy or
// with this base URL pointed at the deployed backend.
const API_BASE = '';

export async function runScreening({ companyName, location, lookbackYears, provider }) {
  const response = await fetch(`${API_BASE}/api/screen`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      company_name: companyName,
      location,
      lookback_years: lookbackYears,
      provider
    })
  });

  if (!response.ok) {
    let detail = `Request failed with status ${response.status}`;
    try {
      const body = await response.json();
      detail = body.detail || detail;
    } catch {
      // ignore parse failure, keep default detail
    }
    throw new Error(detail);
  }

  return response.json();
}

export async function checkHealth() {
  const response = await fetch(`${API_BASE}/api/health`);
  if (!response.ok) throw new Error('Backend health check failed');
  return response.json();
}
