import { useState } from 'react';
import Header from './components/Header';
import EntityForm from './components/EntityForm';
import StatusBanner from './components/StatusBanner';
import ReportView from './components/ReportView';
import { runScreening } from './api/screeningApi';

export default function App() {
  const [status, setStatus] = useState('idle'); // idle | loading | error | done
  const [errorMessage, setErrorMessage] = useState('');
  const [result, setResult] = useState(null);

  const handleSubmit = async (payload) => {
    setStatus('loading');
    setErrorMessage('');
    setResult(null);
    try {
      const data = await runScreening(payload);
      setResult(data);
      setStatus('done');
    } catch (err) {
      setErrorMessage(err.message || 'Unexpected error.');
      setStatus('error');
    }
  };

  return (
    <div className="app-shell">
      <Header />

      <div className="app-body">
        <div className="form-pane">
          <EntityForm onSubmit={handleSubmit} isLoading={status === 'loading'} />
          <StatusBanner mode={status} message={errorMessage} />
          {status === 'idle' && (
            <p className="form-hint">
              Enter an entity name and location, choose a search provider, and run a screening to
              see a color-coded risk assessment with a full evidence trail.
            </p>
          )}
        </div>

        <div className="results-pane">
          {result ? (
            <ReportView result={result} />
          ) : (
            <div className="results-placeholder">
              <div className="results-placeholder-inner">
                No screening has been run yet. Fill in the form on the left and click{' '}
                <strong>Run screening</strong>.
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
