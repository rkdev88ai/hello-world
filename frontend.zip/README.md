# Adverse Media & Sanctions Screening — Enterprise App

A full-stack screening application: a **FastAPI + LangGraph** backend runs the
two-agent screening pipeline (search agent → reporting agent) against either
**SerpAPI** (Google) or a self-hosted **SearXNG** instance — chosen per run
from a toggle in the UI — and a **React** frontend presents the result as a
color-coded, tabbed report with a risk speedometer.

```
ams-screening-app/
├── backend/     FastAPI + LangGraph service (Python)
└── frontend/    React + Vite UI
```

## How it works

- **Provider toggle**: every screening request carries `provider: "serpapi"`
  or `provider: "searxng"`. The backend's `search_providers.py` calls
  whichever one you picked — both are called directly over HTTP (no vendor
  SDK), so they're easy to compare or extend.
- **LLM**: OpenAI only, via `langchain-openai`'s `ChatOpenAI`, configured from
  `backend/config.json` (model name + API key). All three LLM calls in the
  pipeline (query planning, associated-party extraction, final assessment)
  use the same client.
- **Risk speedometer**: the LLM never outputs a raw risk number — it only
  produces categorical labels (`overall_result`, and each finding's
  `category`/`status`/`risk_level`). `backend/app/risk.py` turns those labels
  into a 0–100 score and a red/amber/green color **deterministically**, so
  the mapping is transparent and auditable rather than left to the model to
  invent. Sanctions findings are always red; adverse media, regulatory
  action and litigation are amber; a clean result is green.
- **Report view**: Summary, Findings, Associated Parties, Sources,
  Methodology, and Limitations as separate tabs, with the risk gauge fixed
  in a sidebar so it stays visible as you move between them. A "Download
  full report (.md)" button exports the same markdown report the original
  notebook produced.

## Prerequisites (Windows)

1. **Python 3.11+** — download from https://python.org/downloads and, during
   install, tick **"Add python.exe to PATH"**.
2. **Node.js LTS** (v18+) — download from https://nodejs.org (default
   options). This also installs `npm`.
3. **An OpenAI API key** — https://platform.openai.com/api-keys
4. **A SerpAPI key** (only if you want to use the SerpAPI option) —
   https://serpapi.com
5. **Docker Desktop** (only if you want to self-host SearXNG) —
   https://www.docker.com/products/docker-desktop — see the SearXNG section
   below.

Open **PowerShell** for all the commands below.

## 1. Configure your API keys

Open `backend\config.json` in a text editor and fill in:

```json
{
  "openai_api_key": "sk-...",
  "openai_model": "gpt-4.1-mini",

  "serpapi_api_key": "...",

  "searxng_base_url": "http://localhost:8080",

  "default_lookback_years": 2,
  "max_results_per_query": 20,
  "max_associated_parties": 20,
  "max_party_search_results": 20,

  "cors_allowed_origins": ["http://localhost:5173"]
}
```

- If you only plan to use **SerpAPI**, you can leave `searxng_base_url` as-is
  and skip Docker entirely.
- If you only plan to use **SearXNG**, you can leave `serpapi_api_key` as the
  placeholder — just don't select the SerpAPI toggle in the UI.
- Never commit this file with real keys to source control.

## 2. Start the backend

```powershell
cd ams-screening-app\backend
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python run.py
```

You should see Uvicorn start on `http://127.0.0.1:8000`. Leave this window
open. Verify it's healthy by visiting `http://127.0.0.1:8000/api/health` in
a browser — it should report `"status": "ok"`.

## 3. Start the frontend

Open a **second** PowerShell window:

```powershell
cd ams-screening-app\frontend
npm install
npm run dev
```

Vite will open `http://localhost:5173` automatically. The dev server proxies
`/api/*` calls straight to the backend on port 8000 (see
`frontend/vite.config.js`), so no further configuration is needed.

## 4. (Optional) Self-host SearXNG for the SearXNG toggle

SearXNG's public instances disable JSON output for anti-abuse reasons, so
you need your own instance. The simplest route on Windows is Docker Desktop:

```powershell
docker run -d --name searxng -p 8080:8080 -v searxng-config:/etc/searxng searxng/searxng:latest
```

This starts SearXNG with a default config, but **JSON output is disabled by
default** — you must enable it once:

1. Find the mounted config file. With the volume above, run:
   ```powershell
   docker exec -it searxng sh -c "cat /etc/searxng/settings.yml | Select-String -Pattern 'formats'"
   ```
   (or open the file directly if you mounted a host folder instead of a
   named volume).
2. Edit `settings.yml` so the `search:` section includes:
   ```yaml
   search:
     formats:
       - html
       - json
   ```
   The easiest way to edit a file inside the named volume is to copy it out,
   edit it, and copy it back:
   ```powershell
   docker cp searxng:/etc/searxng/settings.yml .\settings.yml
   notepad .\settings.yml
   # add the `json` format line under `search: formats:`, save, then:
   docker cp .\settings.yml searxng:/etc/searxng/settings.yml
   docker restart searxng
   ```
3. Verify JSON works:
   ```powershell
   curl "http://localhost:8080/search?q=test&format=json"
   ```
   You should get a JSON payload back, not an error page.
4. Confirm `backend\config.json` has `"searxng_base_url": "http://localhost:8080"`
   (the default) and restart the backend (`Ctrl+C` then `python run.py`
   again) so it picks up any config changes.

You can now select **SearXNG** in the app's provider toggle.

**Note on coverage**: SearXNG aggregates whichever underlying engines you
enable (DuckDuckGo, Brave, Bing, etc. — Google scraping is possible but sits
in a legal gray area per Google's ToS, unlike SerpAPI which licenses that
access commercially). Expect thinner adverse-media/regulator coverage from
SearXNG than from SerpAPI's Google results — this is a real tradeoff, not a
bug, and the app's Limitations tab notes it automatically when you use the
SearXNG provider.

## 5. Use the app

1. Open `http://localhost:5173`.
2. Enter an entity name and location, pick a lookback period, and choose
   **SerpAPI** or **SearXNG**.
3. Click **Run screening**. This runs several search queries and three LLM
   calls, so expect it to take anywhere from 15 seconds to a couple of
   minutes depending on how many queries the planner generates and how many
   associated parties are found.
4. Review the risk gauge and the tabbed report. Download the full markdown
   report if needed.

## Building a static frontend (optional)

```powershell
cd ams-screening-app\frontend
npm run build
```

This produces `frontend/dist/` — static files you can serve from any web
server, as long as it's configured to proxy `/api/*` to wherever the FastAPI
backend is running (or you set the frontend's `API_BASE` in
`src/api/screeningApi.js` to the backend's full URL).

## Extending it

- **Add a third search provider**: implement one function in
  `backend/app/search_providers.py` matching the existing signature, add the
  provider name to `SearchProviderName` in `models.py`, and add an option to
  `frontend/src/components/ProviderToggle.jsx`.
- **Change the risk-scoring logic**: everything lives in
  `backend/app/risk.py` — it's plain Python, not a prompt, so it's easy to
  tune the weights or bands without touching the LLM prompts.
- **Swap the LLM provider**: only `backend/app/graph.py`'s `_llm()` function
  constructs the `ChatOpenAI` client — replace it with another LangChain
  chat model if you need to.
